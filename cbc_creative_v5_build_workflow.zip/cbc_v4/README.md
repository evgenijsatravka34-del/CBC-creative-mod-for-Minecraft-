# CBC Creative v0.5.0

Креативный контейнер боеприпасов для Create Big Cannons.

## Что умеет
- Бесконечная автозарядка снарядов
- Меню выбора всех снарядов и взрывателей
- Ползунок времени перезарядки (1–60 сек)
- Кнопка ВКЛ/ВЫКЛ
- Частицы + звук
- Работает на контрапциях Create

## Совместимость с аддонами (новое в 0.5)
Каталог **динамический**. Берёт предметы из тегов CBC:
- `#createbigcannons:big_cannon_projectiles`
- `#createbigcannons:big_cannon_propellant`
- `#createbigcannons:fuzes`

Поэтому снаряды и взрыватели из аддонов (CBC Advanced Technologies, Enhanced Shells, Autogun Revolution и др.) **автоматически** появляются в меню выбора.

## Управление
1. Поставь блок рядом с казённой частью
2. ПКМ → меню
3. Стрелками выбери снаряд и взрыватель
4. Ползунком выставь время
5. Нажми ВКЛ

## Сборка
```bash
./gradlew build
```
Файл: `build/libs/cbc_creative-0.5.0.jar`

## Зависимости
- Minecraft 1.21.1
- NeoForge 21.1.x
- Create 6.0.x
- Create Big Cannons 5.11.x
- Ritchie's Projectile Library

## Сборка JAR через GitHub Actions

В архив добавлен workflow `.github/workflows/build.yml`. Загрузите проект в GitHub, затем откройте вкладку **Actions** и запустите **Build CBC Creative** через **Run workflow**. Если сборка успешна, скачайте артефакт `cbc-creative-jar`; внутри будет JAR из `build/libs`. Если сборка упадёт, откройте лог шага **Build mod** и сохраните полный текст ошибки.
