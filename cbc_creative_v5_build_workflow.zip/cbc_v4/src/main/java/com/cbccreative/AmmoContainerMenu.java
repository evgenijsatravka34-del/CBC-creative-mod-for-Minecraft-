package com.cbccreative;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class AmmoContainerMenu extends AbstractContainerMenu {

    public final AmmoContainerBlockEntity blockEntity;
    private final ContainerData data;

    // data: 0=enabled, 1=reloadSeconds, 2=projectileIndex, 3=fuzeIndex
    public AmmoContainerMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, getBlockEntity(inv, buf.readBlockPos()));
    }

    public AmmoContainerMenu(int id, Inventory inv, AmmoContainerBlockEntity be) {
        super(CbcCreative.AMMO_CONTAINER_MENU.get(), id);
        this.blockEntity = be;

        this.data = new SimpleContainerData(4) {
            @Override
            public int get(int index) {
                return switch (index) {
                    case 0 -> be.isEnabled() ? 1 : 0;
                    case 1 -> be.getReloadSeconds();
                    case 2 -> be.getProjectileIndex();
                    case 3 -> be.getFuzeIndex();
                    default -> 0;
                };
            }

            @Override
            public void set(int index, int value) {
                switch (index) {
                    case 0 -> be.setEnabled(value != 0);
                    case 1 -> be.setReloadSeconds(value);
                    case 2 -> be.setProjectileIndex(value);
                    case 3 -> be.setFuzeIndex(value);
                }
            }
        };
        addDataSlots(data);

        // Инвентарь игрока (снизу) — только для просмотра/переноса, основной выбор через кнопки
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inv, col, 8 + col * 18, 198));
        }
    }

    private static AmmoContainerBlockEntity getBlockEntity(Inventory inv, BlockPos pos) {
        BlockEntity be = inv.player.level().getBlockEntity(pos);
        if (be instanceof AmmoContainerBlockEntity ammo) return ammo;
        throw new IllegalStateException("BlockEntity missing at " + pos);
    }

    public boolean isEnabled() { return data.get(0) != 0; }
    public int getReloadSeconds() { return data.get(1); }
    public int getProjectileIndex() { return data.get(2); }
    public int getFuzeIndex() { return data.get(3); }

    public void setEnabled(boolean v) { data.set(0, v ? 1 : 0); }
    public void setReloadSeconds(int v) { data.set(1, v); }
    public void setProjectileIndex(int v) { data.set(2, v); }
    public void setFuzeIndex(int v) { data.set(3, v); }

    public void cycleProjectile(int delta) {
        blockEntity.cycleProjectile(delta);
        data.set(2, blockEntity.getProjectileIndex());
    }

    public void cycleFuze(int delta) {
        blockEntity.cycleFuze(delta);
        data.set(3, blockEntity.getFuzeIndex());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return blockEntity != null && !blockEntity.isRemoved()
                && player.distanceToSqr(
                blockEntity.getBlockPos().getX() + 0.5,
                blockEntity.getBlockPos().getY() + 0.5,
                blockEntity.getBlockPos().getZ() + 0.5) <= 64.0;
    }
}
