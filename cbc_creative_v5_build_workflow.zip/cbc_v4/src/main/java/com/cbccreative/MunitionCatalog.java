package com.cbccreative;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Динамический каталог снарядов и взрывателей.
 * Берёт предметы из тегов Create Big Cannons + известных аддонов.
 * Любой аддон, который регистрирует предметы в эти теги, автоматически появится в меню.
 */
public final class MunitionCatalog {

    private MunitionCatalog() {}

    // Основные теги CBC
    private static final TagKey<Item> TAG_PROJECTILES = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath("createbigcannons", "big_cannon_projectiles"));
    private static final TagKey<Item> TAG_FUZES = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath("createbigcannons", "fuzes"));
    private static final TagKey<Item> TAG_PROPELLANT = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath("createbigcannons", "big_cannon_propellant"));

    // Запасной список на случай, если теги ещё не загружены / пустые
    private static final String[] FALLBACK_PROJECTILES = {
            "createbigcannons:solid_shot",
            "createbigcannons:he_shell",
            "createbigcannons:ap_shell",
            "createbigcannons:ap_shot",
            "createbigcannons:shrapnel_shell",
            "createbigcannons:grapeshot",
            "createbigcannons:smoke_shell",
            "createbigcannons:fluid_shell",
            "createbigcannons:drop_mortar_shell",
            "createbigcannons:mortar_stone",
            "createbigcannons:traffic_cone",
            "createbigcannons:big_cartridge",
            "createbigcannons:powder_charge"
    };

    private static final String[] FALLBACK_FUZES = {
            "createbigcannons:impact_fuze",
            "createbigcannons:timed_fuze",
            "createbigcannons:proximity_fuze",
            "createbigcannons:delayed_impact_fuze",
            "createbigcannons:inertia_fuze",
            "createbigcannons:delayed_inertia_fuze",
            "createbigcannons:wired_fuze"
    };

    public static List<ItemStack> getProjectiles() {
        Set<Item> items = new LinkedHashSet<>();

        // Из тегов CBC (сюда же попадают аддоны)
        addFromTag(items, TAG_PROJECTILES);
        addFromTag(items, TAG_PROPELLANT);

        // Fallback, если теги пустые
        if (items.isEmpty()) {
            for (String id : FALLBACK_PROJECTILES) {
                Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));
                if (item != null && item != Items.AIR) items.add(item);
            }
        }

        return toStacks(items);
    }

    public static List<ItemStack> getFuzes() {
        Set<Item> items = new LinkedHashSet<>();
        addFromTag(items, TAG_FUZES);

        if (items.isEmpty()) {
            for (String id : FALLBACK_FUZES) {
                Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));
                if (item != null && item != Items.AIR) items.add(item);
            }
        }

        return toStacks(items);
    }

    private static void addFromTag(Set<Item> out, TagKey<Item> tag) {
        try {
            BuiltInRegistries.ITEM.getTagOrEmpty(tag).forEach(holder -> out.add(holder.value()));
        } catch (Exception ignored) {
            // тег ещё не загружен — просто пропускаем
        }
    }

    private static List<ItemStack> toStacks(Set<Item> items) {
        List<ItemStack> list = new ArrayList<>();
        for (Item item : items) {
            list.add(new ItemStack(item));
        }
        return list;
    }

    public static ItemStack getProjectileByIndex(int index) {
        List<ItemStack> list = getProjectiles();
        if (list.isEmpty()) return ItemStack.EMPTY;
        return list.get(Math.floorMod(index, list.size())).copy();
    }

    public static ItemStack getFuzeByIndex(int index) {
        List<ItemStack> list = getFuzes();
        if (list.isEmpty() || index < 0) return ItemStack.EMPTY;
        return list.get(Math.floorMod(index, list.size())).copy();
    }

    public static int projectileCount() {
        return Math.max(1, getProjectiles().size());
    }

    public static int fuzeCount() {
        return getFuzes().size();
    }
}
