package com.cbccreative;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class AmmoContainerScreen extends AbstractContainerScreen<AmmoContainerMenu> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("minecraft", "textures/gui/container/generic_54.png");

    private Button toggleButton;
    private Button projPrev, projNext;
    private Button fuzePrev, fuzeNext;
    private ReloadSlider reloadSlider;

    public AmmoContainerScreen(AmmoContainerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 222;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void init() {
        super.init();
        int x = leftPos;
        int y = topPos;

        toggleButton = Button.builder(getToggleText(), b -> {
            menu.setEnabled(!menu.isEnabled());
            toggleButton.setMessage(getToggleText());
        }).bounds(x + 10, y + 18, 70, 20).build();

        // Снаряд
        projPrev = Button.builder(Component.literal("<"), b -> menu.cycleProjectile(-1))
                .bounds(x + 10, y + 50, 20, 20).build();
        projNext = Button.builder(Component.literal(">"), b -> menu.cycleProjectile(1))
                .bounds(x + 146, y + 50, 20, 20).build();

        // Взрыватель
        fuzePrev = Button.builder(Component.literal("<"), b -> menu.cycleFuze(-1))
                .bounds(x + 10, y + 80, 20, 20).build();
        fuzeNext = Button.builder(Component.literal(">"), b -> menu.cycleFuze(1))
                .bounds(x + 146, y + 80, 20, 20).build();

        // Ползунок времени (1–60 сек)
        reloadSlider = new ReloadSlider(x + 10, y + 110, 156, 20, menu.getReloadSeconds());

        addRenderableWidget(toggleButton);
        addRenderableWidget(projPrev);
        addRenderableWidget(projNext);
        addRenderableWidget(fuzePrev);
        addRenderableWidget(fuzeNext);
        addRenderableWidget(reloadSlider);
    }

    private Component getToggleText() {
        return menu.isEnabled()
                ? Component.literal("§aВКЛ")
                : Component.literal("§cВЫКЛ");
    }

    @Override
    protected void renderBg(GuiGraphics g, float partial, int mx, int my) {
        int x = leftPos;
        int y = topPos;
        // Верхняя часть generic_54
        g.blit(TEXTURE, x, y, 0, 0, imageWidth, 125);
        // Нижняя (инвентарь)
        g.blit(TEXTURE, x, y + 125, 0, 126, imageWidth, 96);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g, mx, my, partial);
        super.render(g, mx, my, partial);
        renderTooltip(g, mx, my);

        int x = leftPos;
        int y = topPos;

        // Иконка и название снаряда
        ItemStack proj = MunitionCatalog.getProjectileByIndex(menu.getProjectileIndex());
        if (!proj.isEmpty()) {
            g.renderItem(proj, x + 80, y + 50);
            g.renderItemDecorations(font, proj, x + 80, y + 50);
            String name = proj.getHoverName().getString();
            if (name.length() > 18) name = name.substring(0, 16) + "..";
            g.drawCenteredString(font, name, x + 88, y + 70, 0xFFFFFF);
        } else {
            g.drawCenteredString(font, "Нет снаряда", x + 88, y + 55, 0xAAAAAA);
        }

        // Иконка и название взрывателя
        ItemStack fuze = MunitionCatalog.getFuzeByIndex(menu.getFuzeIndex());
        if (!fuze.isEmpty()) {
            g.renderItem(fuze, x + 80, y + 80);
            g.renderItemDecorations(font, fuze, x + 80, y + 80);
            String name = fuze.getHoverName().getString();
            if (name.length() > 18) name = name.substring(0, 16) + "..";
            g.drawCenteredString(font, name, x + 88, y + 100, 0xFFFFFF);
        } else {
            g.drawCenteredString(font, "Без взрывателя", x + 88, y + 85, 0xAAAAAA);
        }

        g.drawString(font, "Снаряд", x + 10, y + 40, 0x404040, false);
        g.drawString(font, "Взрыватель", x + 10, y + 70, 0x404040, false);
        g.drawString(font, "Время: " + menu.getReloadSeconds() + " сек", x + 10, y + 132, 0x404040, false);
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        if (toggleButton != null) {
            toggleButton.setMessage(getToggleText());
        }
    }

    private class ReloadSlider extends AbstractSliderButton {
        public ReloadSlider(int x, int y, int w, int h, int currentSeconds) {
            super(x, y, w, h, Component.empty(), (currentSeconds - 1) / 59.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            int sec = 1 + (int) Math.round(value * 59);
            setMessage(Component.literal("Перезарядка: " + sec + " сек"));
        }

        @Override
        protected void applyValue() {
            int sec = 1 + (int) Math.round(value * 59);
            menu.setReloadSeconds(Mth.clamp(sec, 1, 60));
        }
    }
}
