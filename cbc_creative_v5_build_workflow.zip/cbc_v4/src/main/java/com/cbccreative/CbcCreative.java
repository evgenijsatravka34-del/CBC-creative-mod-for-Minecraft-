package com.cbccreative;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(CbcCreative.MODID)
public class CbcCreative {
    public static final String MODID = "cbc_creative";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MODID);

    public static final DeferredBlock<AmmoContainerBlock> AMMO_CONTAINER = BLOCKS.registerBlock(
            "creative_ammo_container", AmmoContainerBlock::new,
            BlockBehaviour.Properties.of().strength(2.0f).requiresCorrectToolForDrops());

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AmmoContainerBlockEntity>> AMMO_CONTAINER_BE =
            BLOCK_ENTITIES.register("creative_ammo_container", () ->
                    BlockEntityType.Builder.of(AmmoContainerBlockEntity::new, AMMO_CONTAINER.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<AmmoContainerMenu>> AMMO_CONTAINER_MENU =
            MENUS.register("creative_ammo_container", () ->
                    IMenuTypeExtension.create(AmmoContainerMenu::new));

    static {
        ITEMS.registerSimpleBlockItem(AMMO_CONTAINER);
    }

    public CbcCreative(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        MENUS.register(bus);
        bus.addListener(ClientSetup::onClientSetup);
    }
}
