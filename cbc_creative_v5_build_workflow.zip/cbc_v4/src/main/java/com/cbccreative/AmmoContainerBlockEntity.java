package com.cbccreative;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate.StructureBlockInfo;
import org.jetbrains.annotations.Nullable;
import rbasamoyai.createbigcannons.cannons.big_cannons.BigCannonBlock;
import rbasamoyai.createbigcannons.cannons.big_cannons.IBigCannonBlockEntity;
import rbasamoyai.createbigcannons.munitions.big_cannon.BigCannonMunitionBlock;

public class AmmoContainerBlockEntity extends BlockEntity implements MenuProvider {

    private int projectileIndex = 0;
    private int fuzeIndex = -1; // -1 = без взрывателя
    private int reloadSeconds = 3;
    private boolean enabled = false;
    private int timer = 0;

    public AmmoContainerBlockEntity(BlockPos pos, BlockState state) {
        super(CbcCreative.AMMO_CONTAINER_BE.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AmmoContainerBlockEntity be) {
        if (!be.enabled) return;
        ItemStack template = be.getSelectedProjectile();
        if (template.isEmpty()) return;
        if (++be.timer < be.reloadSeconds * 20) return;
        be.timer = 0;
        be.tryLoadCannon(level, pos, template);
    }

    private void tryLoadCannon(Level level, BlockPos pos, ItemStack template) {
        if (!(template.getItem() instanceof BlockItem blockItem)) return;
        if (!(blockItem.getBlock() instanceof BigCannonMunitionBlock munition)) return;

        ItemStack toLoad = template.copy();
        ItemStack fuze = getSelectedFuze();
        if (!fuze.isEmpty()) {
            applyFuze(toLoad, fuze);
        }

        for (Direction dir : Direction.values()) {
            BlockPos neighborPos = pos.relative(dir);
            BlockEntity neighbor = level.getBlockEntity(neighborPos);
            if (!(neighbor instanceof IBigCannonBlockEntity cannonBE)) continue;

            BlockState cannonState = level.getBlockState(neighborPos);
            if (!(cannonState.getBlock() instanceof BigCannonBlock cannonBlock)) continue;

            Direction cannonFacing = cannonBlock.getFacing(cannonState);
            StructureBlockInfo info = munition.getHandloadingInfo(
                    toLoad,
                    BlockPos.ZERO,
                    cannonFacing,
                    level.registryAccess()
            );

            if (cannonBE.cannonBehavior().tryLoadingBlock(info)) {
                cannonBE.cannonBehavior().blockEntity.setChanged();
                level.sendBlockUpdated(neighborPos, cannonState, cannonState, 3);

                if (level instanceof ServerLevel serverLevel) {
                    double x = neighborPos.getX() + 0.5;
                    double y = neighborPos.getY() + 0.7;
                    double z = neighborPos.getZ() + 0.5;
                    serverLevel.sendParticles(ParticleTypes.SMOKE, x, y, z, 10, 0.3, 0.3, 0.3, 0.02);
                    serverLevel.sendParticles(ParticleTypes.FLAME, x, y, z, 6, 0.2, 0.2, 0.2, 0.01);
                    serverLevel.sendParticles(ParticleTypes.CRIT, x, y, z, 5, 0.25, 0.25, 0.25, 0.05);
                    level.playSound(null, neighborPos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.7f, 1.2f);
                    level.playSound(null, neighborPos, SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.BLOCKS, 0.4f, 0.8f);
                }
                setChanged();
                return;
            }
        }
    }

    private void applyFuze(ItemStack shell, ItemStack fuze) {
        CustomData data = shell.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
        CompoundTag tag = data.copyTag();
        CompoundTag fuzeTag = new CompoundTag();
        fuzeTag.putString("id", net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(fuze.getItem()).toString());
        tag.put("Fuze", fuzeTag);
        shell.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    public ItemStack getSelectedProjectile() {
        return MunitionCatalog.getProjectileByIndex(projectileIndex);
    }

    public ItemStack getSelectedFuze() {
        return MunitionCatalog.getFuzeByIndex(fuzeIndex);
    }

    public int getProjectileIndex() { return projectileIndex; }
    public int getFuzeIndex() { return fuzeIndex; }

    public void setProjectileIndex(int index) {
        this.projectileIndex = Math.max(0, index);
        setChanged();
        sync();
    }

    public void setFuzeIndex(int index) {
        this.fuzeIndex = index;
        setChanged();
        sync();
    }

    public void cycleProjectile(int delta) {
        int count = Math.max(1, MunitionCatalog.projectileCount());
        projectileIndex = Math.floorMod(projectileIndex + delta, count);
        setChanged();
        sync();
    }

    public void cycleFuze(int delta) {
        int count = MunitionCatalog.fuzeCount();
        if (count == 0) {
            fuzeIndex = -1;
        } else if (fuzeIndex < 0) {
            fuzeIndex = delta > 0 ? 0 : count - 1;
        } else {
            int next = fuzeIndex + delta;
            if (next < 0 || next >= count) fuzeIndex = -1;
            else fuzeIndex = next;
        }
        setChanged();
        sync();
    }

    public void setEnabled(boolean value) {
        this.enabled = value;
        setChanged();
        sync();
    }

    public boolean isEnabled() { return enabled; }

    public void setReloadSeconds(int seconds) {
        this.reloadSeconds = Math.max(1, Math.min(60, seconds));
        setChanged();
        sync();
    }

    public int getReloadSeconds() { return reloadSeconds; }

    private void sync() {
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.cbc_creative.creative_ammo_container");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new AmmoContainerMenu(id, inv, this);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.saveAdditional(tag, reg);
        tag.putInt("proj", projectileIndex);
        tag.putInt("fuze", fuzeIndex);
        tag.putInt("reload", reloadSeconds);
        tag.putBoolean("enabled", enabled);
        tag.putInt("timer", timer);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.loadAdditional(tag, reg);
        projectileIndex = Math.max(0, tag.getInt("proj"));
        fuzeIndex = tag.getInt("fuze");
        reloadSeconds = Math.max(1, tag.getInt("reload"));
        enabled = tag.getBoolean("enabled");
        timer = tag.getInt("timer");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider reg) {
        CompoundTag tag = super.getUpdateTag(reg);
        saveAdditional(tag, reg);
        return tag;
    }

    @Nullable
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
